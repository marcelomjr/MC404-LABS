CROSS_COMPILE=arm-none-eabi-
export PATH=$PATH:/home/giuliano/mc404/borin/arm/armv7simulatorplatform/armv7/ARMV7_INSTALL/libexec
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/giuliano/mc404/borin/arm/armv7simulatorplatform/systemc-2.3.1/SYSTEMC_INSTALL/lib-linux64
